// Deployed contract addresses consumed from the TimbSwap protocol.
// Single source of truth: TimbSwap/config.js — keep this file in sync on every deploy.
// SegmentBoard is deployed from the TimbSwap Foundry project (not this repo).

export const ADDRESSES = {
  arbitrumSepolia: {
    chainId: 421614,
    SegmentBoard: "0x0000000000000000000000000000000000000000", // TODO: set on first deploy
    TimbPrize:    "0x35976f4D0000000000000000000000000000002432", // from TimbSwap/config.js
    TIMBSToken:   "0x2Aaa61E20000000000000000000000000000000000", // from TimbSwap/config.js
    TimbTreasury: "0xd3F400420000000000000000000000000000000D5c", // from TimbSwap/config.js
    // add others (Router, PrizeEscrow, ...) as the app needs them
  },
};

// NOTE: the placeholder-padded addresses above are reminders to copy the exact,
// full checksummed values from TimbSwap/config.js — do not ship these as-is.
